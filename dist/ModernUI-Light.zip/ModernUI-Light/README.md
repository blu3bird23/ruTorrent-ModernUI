# ModernUI Light — light theme for ruTorrent

The light variant of **ModernUI**, a Bootstrap 5 based interface for ruTorrent 5.3.x.
White surfaces on a soft blue page background, with indigo/cyan accents.

![ModernUI Light theme](screenshot.png)

This folder is the installable theme. The full documentation, the dark variant and release
archives live in the repository root.

## Install

Copy this folder to:

```text
rutorrent/plugins/theme/themes/ModernUI-Light
```

Then choose **ModernUI-Light** under **Settings → Theme** in ruTorrent. The folder name is the name
shown in the theme picker.

## Palette

```css
--mui-accent:        #4f46e5;
--mui-accent-2:      #0891b2;
--mui-bg:            #eef2f8;
--mui-surface:       #ffffff;
--mui-surface-2:     #f4f7fb;
--mui-text:          #16203a;
```

All tokens are defined at the top of `style.css`.

## Files

| File | Purpose |
| --- | --- |
| `style.css` | Design tokens, navigation, sidebar, layout, dialogs, forms |
| `stable.css` | Torrent table and progress meters |
| `plugins.css` | Plugin widgets |
| `init.js` | Row height, progress colours, theme hint, cache busting |
| `preview.html` | Standalone preview page |
| `images/`, `font/` | Bundled icons and Roboto |

## License

GNU General Public License v3.0 or later. See the repository's `LICENSE` and `ATTRIBUTION.md`.
