# ModernUI — dark theme for ruTorrent

The dark variant of **ModernUI**, a Bootstrap 5 based interface for ruTorrent 5.3.x.
Deep navy surfaces with indigo/cyan accents.

![ModernUI dark theme](screenshot.png)

This folder is the installable theme. The full documentation, the light variant and release
archives live in the repository root.

## Install

Copy this folder to:

```text
rutorrent/plugins/theme/themes/ModernUI
```

Then choose **ModernUI** under **Settings → Theme** in ruTorrent. The folder name is the name shown
in the theme picker.

## Palette

```css
--mui-accent:        #6366f1;
--mui-accent-2:      #22d3ee;
--mui-bg:            #080d18;
--mui-surface:       #0f172a;
--mui-surface-2:     #162033;
--mui-text:          #e8eefb;
```

All tokens are defined at the top of `style.css`.

## Files

| File | Purpose |
| --- | --- |
| `style.css` | Design tokens, navigation, sidebar, layout, dialogs, forms |
| `stable.css` | Torrent table and progress meters |
| `plugins.css` | Plugin widgets |
| `init.js` | Row height, progress colours, theme hint |
| `preview.html` | Standalone preview page |
| `images/`, `font/` | Bundled icons and Roboto |

## License

GNU General Public License v3.0 or later. See the repository's `LICENSE` and `ATTRIBUTION.md`.
